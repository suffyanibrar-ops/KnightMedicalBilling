"use client";

import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, BadgeCheck, Check, Phone, ShieldCheck, Sparkles } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { site } from "@/lib/site";
import { Icon } from "./icon";

const words = ["custom tailored.", "filed in 24 hours.", "fully managed.", "audit ready."];

const promises = [
  { title: "5 Days Process", detail: "Fast & easy", icon: "Zap" },
  { title: "No Prepayment", detail: "No hidden fees", icon: "Wallet" },
  { title: "24/5 Support", detail: "Multilingual", icon: "Headphones" },
  { title: "99.9%", detail: "Claim acceptance", icon: "BadgeCheck" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (index: number) => ({ opacity: 1, y: 0, transition: { duration: 0.7, delay: 0.08 * index, ease: [0.22, 1, 0.36, 1] as const } }),
};

export function Hero() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setIndex((value) => (value + 1) % words.length), 2800);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-mist-50 via-white to-white">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[url('/images/about-team.jpg')] bg-cover bg-center opacity-[0.22]" />
        <div className="grid-lines absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_at_top,black,transparent_75%)]" />
        <div className="absolute -right-24 top-10 h-[30rem] w-[30rem] rounded-full bg-brand-200/35 blur-[110px]" />
        <div className="absolute -left-32 top-40 h-80 w-80 rounded-full bg-mint-100/70 blur-[90px]" />
      </div>

      <div className="shell relative grid items-center gap-12 pb-14 pt-10 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10 lg:pb-20 lg:pt-16">
        <div>
          <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="flex flex-wrap items-center gap-2.5">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/80 px-3 py-1.5 text-[0.7rem] font-extrabold uppercase tracking-[0.16em] text-brand-700 shadow-sm">
              <Sparkles className="h-3.5 w-3.5" /> Custom tailored billing
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-mist-200 bg-white/70 px-3 py-1.5 text-[0.7rem] font-bold text-ink-700">
              <ShieldCheck className="h-3.5 w-3.5 text-mint-600" /> HIPAA compliant
            </span>
          </motion.div>

          <motion.h1 initial="hidden" animate="show" custom={1} variants={fadeUp} className="mt-5 text-[clamp(2.5rem,6vw,4.35rem)] font-extrabold leading-[1.02] tracking-[-0.045em] text-ink-950">
            Your revenue cycle,
            <span className="relative mt-1 flex items-baseline gap-3">
              <span className="relative inline-block min-w-[10.5ch] overflow-hidden whitespace-nowrap align-bottom">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span
                    key={words[index]}
                    initial={{ y: "110%", opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: "-110%", opacity: 0 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="display-serif inline-block bg-gradient-to-r from-brand-600 via-brand-500 to-mint-500 bg-clip-text text-transparent"
                  >
                    {words[index]}
                  </motion.span>
                </AnimatePresence>
              </span>
            </span>
          </motion.h1>

          <motion.p initial="hidden" animate="show" custom={2} variants={fadeUp} className="mt-6 max-w-xl text-[1rem] leading-relaxed text-ink-600/85 sm:text-[1.06rem]">
            We have a <span className="font-extrabold text-ink-900">99.9% claim acceptance rate</span>. From the moment your patient walks in until you receive payment, our RCM team supports your growth by fixing the problem areas in your revenue cycle management.
          </motion.p>

          <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp} className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Link href="/schedule-form" className="btn btn-primary group px-6 py-4 text-[0.95rem]">
              Schedule a free consultation
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.4} />
            </Link>
            <a href={site.phoneHref} className="btn btn-light group px-6 py-4 text-[0.95rem]">
              <Phone className="h-4 w-4 text-brand-600" strokeWidth={2} />
              {site.phone}
            </a>
          </motion.div>

          <motion.div initial="hidden" animate="show" custom={4} variants={fadeUp} className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.75rem] font-semibold text-ink-600/70">
            {["No prepayment", "No hidden fees", "Live in 5 days"].map((item) => (
              <span key={item} className="flex items-center gap-1.5">
                <Check className="h-4 w-4 text-mint-600" strokeWidth={2.6} /> {item}
              </span>
            ))}
          </motion.div>

          <motion.div initial="hidden" animate="show" custom={5} variants={fadeUp} className="mt-8 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            {promises.map((promise) => (
              <div key={promise.title} className="rounded-2xl border border-mist-200 bg-white/80 p-3 backdrop-blur transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-sm">
                <span className="grid h-8 w-8 place-items-center rounded-xl bg-brand-50 text-brand-700">
                  <Icon name={promise.icon} className="h-4 w-4" />
                </span>
                <p className="mt-2 text-[0.78rem] font-extrabold leading-tight text-ink-950">{promise.title}</p>
                <p className="mt-0.5 text-[0.62rem] font-semibold text-ink-600/60">{promise.detail}</p>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 30, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }} className="relative mx-auto w-full max-w-[34rem] lg:max-w-none">
          <div className="absolute -inset-4 -z-10 rounded-[2.6rem] bg-gradient-to-tr from-brand-100 via-white to-mint-100 opacity-80 blur-[1px]" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/70 bg-white shadow-[0_50px_90px_-50px_rgba(4,20,31,0.55)]">
            <div className="relative aspect-[4/4.2] w-full">
              <Image src="/images/kmb-service-billing.jpg" alt="Medical billing and coding specialists at work" fill className="object-cover object-center" sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 640px" priority />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-ink-950/15 to-transparent" />
            </div>
            <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5 sm:p-6">
              <div className="text-white">
                <p className="text-[0.62rem] font-extrabold uppercase tracking-[0.2em] text-brand-200">Revenue cycle management</p>
                <p className="mt-1.5 max-w-[16rem] text-[1.05rem] font-extrabold leading-snug tracking-tight sm:text-lg">An extension of your staff, from check-in to payment.</p>
              </div>
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/15 backdrop-blur-md">
                <BadgeCheck className="h-5 w-5 text-white" />
              </span>
            </div>
          </div>

          <motion.div initial={{ opacity: 0, x: -20, y: 10 }} animate={{ opacity: 1, x: 0, y: 0 }} transition={{ duration: 0.7, delay: 0.6, ease: [0.22, 1, 0.36, 1] }} className="animate-float absolute -left-3 top-8 w-[10.5rem] rounded-2xl border border-white bg-white/95 p-3.5 shadow-[0_20px_45px_-20px_rgba(4,20,31,0.4)] backdrop-blur sm:-left-8 sm:top-12 sm:w-[12.5rem]">
            <div className="flex items-center justify-between">
              <p className="text-[0.6rem] font-extrabold uppercase tracking-[0.14em] text-ink-600/60">Claim acceptance</p>
              <span className="rounded-full bg-mint-50 px-1.5 py-0.5 text-[0.55rem] font-extrabold text-mint-700">99.9%</span>
            </div>
            <p className="mt-1 text-[1.7rem] font-extrabold leading-none tracking-tight text-ink-950">Clean claims</p>
            <div className="mt-2.5 flex h-8 items-end gap-1">
              {[42, 55, 48, 66, 60, 76, 72, 88, 96].map((height, barIndex) => (
                <motion.span key={barIndex} initial={{ height: 2 }} animate={{ height: `${height}%` }} transition={{ duration: 0.7, delay: 0.8 + barIndex * 0.06, ease: "easeOut" }} className="w-full rounded-sm bg-gradient-to-t from-brand-200 to-brand-500" />
              ))}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20, y: -10 }} animate={{ opacity: 1, x: 0, y: 0 }} transition={{ duration: 0.7, delay: 0.8, ease: [0.22, 1, 0.36, 1] }} className="absolute -right-2 top-[46%] w-[9.5rem] rounded-2xl border border-white bg-white/95 p-3.5 shadow-[0_20px_45px_-20px_rgba(4,20,31,0.4)] backdrop-blur sm:-right-6 sm:w-[11rem]">
            <p className="text-[0.6rem] font-extrabold uppercase tracking-[0.14em] text-ink-600/60">Claims filed in</p>
            <div className="mt-1 flex items-baseline gap-1.5">
              <p className="text-[1.7rem] font-extrabold leading-none tracking-tight text-ink-950">24</p>
              <span className="text-[0.65rem] font-bold text-mint-700">hours</span>
            </div>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-mist-100">
              <motion.div initial={{ width: 0 }} animate={{ width: "96%" }} transition={{ duration: 1, delay: 1 }} className="h-full rounded-full bg-gradient-to-r from-mint-500 to-brand-400" />
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 1, ease: [0.22, 1, 0.36, 1] }} className="absolute -bottom-5 left-1/2 flex w-[15rem] -translate-x-1/2 items-center gap-2.5 rounded-2xl border border-white bg-white/95 px-3.5 py-3 shadow-[0_20px_45px_-20px_rgba(4,20,31,0.4)] backdrop-blur sm:left-auto sm:right-8 sm:translate-x-0">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-mint-50 text-mint-700">
              <BadgeCheck className="h-4 w-4" strokeWidth={2.2} />
            </span>
            <div>
              <p className="text-[0.72rem] font-extrabold leading-none text-ink-900">24/5 support</p>
              <p className="mt-1 text-[0.62rem] font-semibold text-ink-600/65">Multilingual · Indianapolis, IN</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
