import { ArrowUpRight, Clock, Mail, MapPin, Phone, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { audiences, services, site, specialties } from "@/lib/site";
import { Logo } from "./logo";
import { NewsletterForm } from "./newsletter-form";

const companyLinks = [
  { label: "About KMB", href: "/about" },
  { label: "Our Process", href: "/our-process" },
  { label: "Who We Serve", href: "/who-we-serve" },
  { label: "Results", href: "/results" },
  { label: "Resources", href: "/insights" },
  { label: "FAQ", href: "/faq" },
  { label: "Contact", href: "/contact" },
];

const compliance = ["HIPAA compliant", "Data & document security", "Strict quality control", "Full transparency"];

export function SiteFooter() {
  return (
    <footer className="relative overflow-hidden bg-ink-950 text-white">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-32 top-0 h-96 w-96 rounded-full bg-brand-600/20 blur-3xl" />
        <div className="absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-mint-600/10 blur-3xl" />
        <div className="dot-grid absolute inset-0 opacity-[0.12]" />
      </div>

      <div className="shell relative">
        <div className="grid gap-10 border-b border-white/10 py-14 lg:grid-cols-[1.15fr_2fr] lg:gap-16">
          <div>
            <Logo variant="light" markSize={48} />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/60">{site.description}</p>
            <div className="mt-6 max-w-sm">
              <p className="mb-2 text-[0.68rem] font-extrabold uppercase tracking-[0.2em] text-brand-300">Billing insights, monthly</p>
              <NewsletterForm />
            </div>
            <div className="mt-6 flex gap-2">
              {[
                { path: "M4.98 3.5C4.98 4.88 3.87 6 2.49 6S0 4.88 0 3.5 1.11 1 2.49 1s2.49 1.12 2.49 2.5zM.24 8h4.5V23H.24V8zm7.4 0h4.31v2.05h.06c.6-1.14 2.07-2.34 4.26-2.34 4.56 0 5.4 3 5.4 6.9V23h-4.5v-6.56c0-1.57-.03-3.58-2.18-3.58-2.18 0-2.51 1.7-2.51 3.46V23H7.64V8z", label: "LinkedIn" },
                { path: "M18.9 2H22l-6.77 7.73L23.2 22h-6.24l-4.89-6.39L6.5 22H3.37l7.24-8.27L2.8 2h6.4l4.42 5.84L18.9 2zm-1.09 18.1h1.72L7.28 3.8H5.43L17.8 20.1z", label: "X" },
                { path: "M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.09 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.7 4.53-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.96.93-1.96 1.89v2.26h3.33l-.53 3.49h-2.8V24C19.61 23.09 24 18.1 24 12.07z", label: "Facebook" },
              ].map(({ path, label }) => (
                <a
                  key={label}
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noreferrer noopener"
                  aria-label={label}
                  className="grid h-9 w-9 place-items-center rounded-full border border-white/15 text-white/70 transition-colors hover:border-brand-300 hover:text-white"
                >
                  <svg viewBox="0 0 24 24" fill="currentColor" className="h-3.5 w-3.5" aria-hidden="true">
                    <path d={path} />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <p className="mb-4 text-[0.68rem] font-extrabold uppercase tracking-[0.2em] text-white/40">Services</p>
              <ul className="space-y-2.5">
                {services.slice(0, 6).map((service) => (
                  <li key={service.slug}>
                    <Link href={`/services/${service.slug}`} className="text-sm text-white/65 transition-colors hover:text-white">
                      {service.short}
                    </Link>
                  </li>
                ))}
                <li>
                  <Link href="/services" className="text-sm font-semibold text-brand-300 transition-colors hover:text-white">
                    All services →
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <p className="mb-4 text-[0.68rem] font-extrabold uppercase tracking-[0.2em] text-white/40">Who we serve</p>
              <ul className="space-y-2.5">
                {audiences.map((audience) => (
                  <li key={audience.slug}>
                    <Link href={`/who-we-serve/${audience.slug}`} className="text-sm text-white/65 transition-colors hover:text-white">
                      {audience.name}
                    </Link>
                  </li>
                ))}
                <li>
                  <Link href="/specialties" className="text-sm font-semibold text-brand-300 transition-colors hover:text-white">
                    {specialties.length}+ specialties →
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <p className="mb-4 text-[0.68rem] font-extrabold uppercase tracking-[0.2em] text-white/40">Company</p>
              <ul className="space-y-2.5">
                {companyLinks.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-white/65 transition-colors hover:text-white">
                      {link.label}
                    </Link>
                  </li>
                ))}
                <li>
                  <Link href="/hipaa-compliance" className="text-sm text-white/65 transition-colors hover:text-white">
                    HIPAA notice
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <p className="mb-4 text-[0.68rem] font-extrabold uppercase tracking-[0.2em] text-white/40">Talk to us</p>
              <ul className="space-y-3 text-sm text-white/65">
                <li>
                  <a href={site.phoneHref} className="flex items-start gap-2.5 transition-colors hover:text-white">
                    <Phone className="mt-0.5 h-4 w-4 shrink-0 text-brand-300" />
                    {site.phone}
                  </a>
                </li>
                <li>
                  <a href={`mailto:${site.email}`} className="flex items-start gap-2.5 break-all transition-colors hover:text-white">
                    <Mail className="mt-0.5 h-4 w-4 shrink-0 text-brand-300" />
                    {site.email}
                  </a>
                </li>
                <li className="flex items-start gap-2.5">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-300" />
                  {site.address}
                </li>
                <li className="flex items-start gap-2.5">
                  <Clock className="mt-0.5 h-4 w-4 shrink-0 text-brand-300" />
                  {site.hours}
                </li>
              </ul>
              <Link href="/schedule-form" className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-brand-500">
                Schedule a consultation <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-3 border-b border-white/10 py-5">
          <span className="flex items-center gap-2 text-[0.7rem] font-bold uppercase tracking-[0.16em] text-white/45">
            <ShieldCheck className="h-4 w-4 text-mint-300" /> Compliance
          </span>
          {compliance.map((item) => (
            <span key={item} className="text-xs font-semibold text-white/60">
              {item}
            </span>
          ))}
        </div>

        <div className="flex flex-col gap-4 py-6 text-xs text-white/45 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {site.name}. All rights reserved. Serving facilities across the United States.
          </p>
          <div className="flex flex-wrap gap-x-5 gap-y-2">
            <Link href="/privacy-policy" className="transition-colors hover:text-white">
              Privacy policy
            </Link>
            <Link href="/terms-of-service" className="transition-colors hover:text-white">
              Terms of service
            </Link>
            <Link href="/hipaa-compliance" className="transition-colors hover:text-white">
              HIPAA & security
            </Link>
            <Link href="/faq" className="transition-colors hover:text-white">
              FAQ
            </Link>
          </div>
        </div>
      </div>

      <div aria-hidden className="pointer-events-none relative select-none overflow-hidden">
        <p className="-mb-6 translate-y-4 bg-gradient-to-b from-white/[0.07] to-transparent bg-clip-text text-center text-[17vw] font-extrabold leading-none tracking-[-0.06em] text-transparent">
          KNIGHT
        </p>
      </div>
    </footer>
  );
}
