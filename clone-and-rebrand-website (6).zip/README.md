# Knight Medical Billing

Custom-tailored medical billing and revenue cycle management website, admin console and form pipeline.

- **Stack:** Next.js 16 (App Router) · React 19 · Tailwind CSS 4 · Drizzle ORM · PostgreSQL · Framer Motion
- **Website:** home, services (10), who we serve (5 + index), specialties (30 + index), process, results,
  about, resources (6 guides), FAQ, contact, schedule a consultation, HIPAA, privacy, terms
- **Admin console:** `/admin` — submissions, email outbox, subscribers, ROI estimates, CSV exports
- **Forms:** consultation wizard, contact, newsletter, ROI calculator — stored in Postgres and emailed to the owner

## Quick start

```bash
npm install
cp .env.example .env      # optional — the site runs without any env vars
npm run dev               # http://localhost:3000
```

Database (optional, enables admin storage):

```bash
npx drizzle-kit push
node --experimental-strip-types scripts/seed.mjs
```

Production:

```bash
npm run build
npm run start          # honours the PORT environment variable
```

Images use `next/image`; `res.cloudinary.com` is allow-listed in
`next.config.ts`, and `sharp` is installed so optimisation works on any Node host.

Database schema:

```bash
npm run db:push        # drizzle-kit push (reads DATABASE_URL)
npm run db:seed        # node --experimental-strip-types scripts/seed.mjs
```

This is a full-stack app — do not add `output: 'export'`.

Admin password: `Medical#213` (digest stored server-side; override with `ADMIN_PASSWORD_HASH`).

Full hosting instructions, email setup and troubleshooting: **[DEPLOYMENT.md](./DEPLOYMENT.md)**
