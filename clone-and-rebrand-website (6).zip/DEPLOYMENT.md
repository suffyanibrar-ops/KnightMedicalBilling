# Deployment guide — Knight Medical Billing

A **full-stack Next.js 16 (App Router)** application with route handlers, server actions, middleware
(`proxy.ts`), Drizzle ORM and PostgreSQL. It is **not** a static site and must not be exported
statically — the admin console, form APIs and database require a server runtime.

Any Node.js 22 host works: Vercel, Render, Railway, Fly.io, Google Cloud Run, Google AI Studio,
Northflank, a Docker container or a VPS. No host-specific files or attributes are required.

---

## 1. Build and run

```bash
npm install
npm run build
npm run start        # honours PORT; binds 0.0.0.0 by default
```

`npm run dev` starts the development server on `http://localhost:3000`.

Environment variables (all documented in `.env.example`):

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | For admin/forms/DB | Hosted Postgres connection string (`?sslmode=require` in production) |
| `NEXT_PUBLIC_SITE_URL` | Recommended | Absolute site URL for canonical tags, sitemap, Open Graph, emails |
| `ADMIN_EMAIL` | Optional | Owner inbox for notifications (default `admin@knightmedicalbilling.com`) |
| `ADMIN_PASSWORD_HASH` | Optional | Overrides the default admin password digest |
| `ADMIN_SESSION_SECRET` | Optional | Overrides the session-signing secret |
| `RESEND_API_KEY` + `MAIL_FROM` | Optional | Email channel #1 |
| `SMTP_HOST`/`SMTP_PORT`/`SMTP_USER`/`SMTP_PASS` | Optional | Email channel #2 |

`.env` is git-ignored; only `.env.example` is committed. Never commit credentials.

---

## 2. Database

The connection string is read from `process.env.DATABASE_URL` in both places:

- `src/db/index.ts` — Drizzle client (lazy pool, TLS enabled automatically for non-local hosts)
- `drizzle.config.ts` — Drizzle Kit (throws a clear error if the variable is missing)

No credentials are hardcoded and there is no SQLite or other local-only driver.

```bash
npm run db:push      # npx drizzle-kit push — apply src/db/schema.ts
npm run db:seed      # node --experimental-strip-types scripts/seed.mjs
npm run db:generate  # optional: emit SQL migrations
```

Run both commands once against your production database after the first deploy.

**Resilience:** if `DATABASE_URL` is missing, public pages still render from built-in content and
`/api/health` reports `"database":"not-configured"`. Admin pages show setup instructions. Nothing
crashes at import time.

---

## 3. Images

`next/image` is used throughout. Local assets live in `public/images`. External images are
allow-listed in `next.config.ts`:

```ts
images: { remotePatterns: [{ protocol: 'https', hostname: 'res.cloudinary.com' }] }
```

`sharp` is a production dependency, so the optimizer works on any Node host. Hosts with an
image-optimization service (Vercel, Netlify) use it automatically.

---

## 4. Admin console

- URL: `/admin` → redirects to `/admin/login`
- Default password: `Medical#213` (stored only as a peppered SHA-256 digest in
  `src/lib/admin-session.ts`; override with `ADMIN_PASSWORD_HASH`)
- Sessions: signed HttpOnly cookie, 8-hour expiry, verified in `src/proxy.ts` **and** in every
  admin page
- Brute-force protection: 5 attempts / 15 minutes per IP, all attempts audit-logged
- Pages: overview, submissions (status pipeline, search, CSV export), email outbox (retry + test
  email), subscribers, ROI estimates

---

## 5. Email notifications

Every submission is stored in the database and written to `email_outbox`, then delivered to
`ADMIN_EMAIL` through the first configured channel (Resend → SMTP → optional FormSubmit relay).
Delivery runs after the response is flushed, so visitors never wait.

Configure a channel, then use **Admin → Email delivery → Send test email** to confirm, and
**Retry queued** to deliver anything captured earlier. With no channel configured, messages remain
queued in the admin panel — nothing is lost.

---

## 6. Google AI Studio / Cloud Run preview

`next.config.ts` allow-lists the AI Studio dev host in `allowedDevOrigins`, which resolves
cross-origin dev warnings:

```ts
allowedDevOrigins: ['ais-dev-vdquyz2ozg4bjeiy4hgdx6-797145459235.asia-southeast1.run.app']
```

If your preview hostname changes, add the new hostname to that array. Expose the port reported by the
platform (Cloud Run sets `PORT`; `npm run start` reads it automatically).

---

## 7. Troubleshooting

| Symptom | Fix |
| --- | --- |
| Build error `DATABASE_URL is not set` | Only Drizzle CLI commands need it. Set `DATABASE_URL`, or skip DB commands for a content-only preview. |
| `relation "leads" does not exist` | Run `npm run db:push` against the deployed database. |
| Cloudinary image fails to load | Confirm the hostname is present in `images.remotePatterns`. |
| Cross-origin dev warning in AI Studio | Add the exact preview origin to `allowedDevOrigins`. |
| Admin shows "connect a database" | `DATABASE_URL` is missing in that environment. |
| Emails queued, never sent | No channel configured — add `RESEND_API_KEY` or SMTP and retry. |
| Blank preview | The server process is not running. Check `/api/health` and the platform port. |

---

## 8. Pre-launch checklist

- [ ] `DATABASE_URL` set and `npm run db:push && npm run db:seed` executed
- [ ] `NEXT_PUBLIC_SITE_URL` set to the real domain
- [ ] `ADMIN_PASSWORD_HASH` rotated from the default; `ADMIN_SESSION_SECRET` randomised
- [ ] Email channel configured and test email received
- [ ] `/api/health` monitored; `/admin` blocked from indexing (already configured)
- [ ] `npm audit --omit=dev` reviewed on your release cadence
